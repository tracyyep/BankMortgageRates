var app = angular
            .module('mortgageModule', [])
            .filter("checkGender", function() {
                return function(gender) {
                    switch(gender){
                        case 1 :
                           return "Male";
                        case 2 :
                           return "Female";
                        case 3 :
                           return "Not disclosed";
                        default:
                           return "Not match";

                    }
                }
            });

    app.controller("mortgageController", function ($scope){

        var banks = [
            {bank_title:"Wells Fargo Bank ", rate: "4.250", APR: "4.275", bank_url:"www.wellsfargo.com", likes:0, dislikes:0},
            {bank_title:"US Bank", rate: "4.125", APR: "4.197", bank_url:"www.usbank.com" ,likes:0, dislikes:0},
            {bank_title:"Quickens  Loan", rate: "3.25", APR: "3.67", bank_url:"www.quickenloans.com",  likes:0, dislikes:0}

        ];

        $scope.banks = banks;

        $scope.sortColumn = "bank_title";

        $scope.reverseSort= false;

        $scope.sortData = function(column) {
            $scope.reverseSort = ($scope.sortColumn == column) ? !$scope.reverseSort : false;
            $scope.sortColumn = column;
        }

        $scope.getSortClass = function (column ) {
            if($scope.sortColumn == column) {
                return $scope.reverseSort ? 'arrow_down' : 'arrow_up' ;
            }

            return '';
        }



        $scope.BankView = "Bank-Table.html";

        $scope.newBank= {};
        $scope.newBank.bank_title="";
        $scope.newBank.rate="";
        $scope.newBank.APR="";
        $scope.newBank.bank_url="";
        $scope.addBank = function () {        
            $scope.banks.push(
                    {bank_title:  $scope.newBank.bank_title,
                    rate:         $scope.newBank.rate,
                    APR:          $scope.newBank.APR,
                    bank_url:     $scope.newBank.bank_url}
            );  

            $scope.newBank.bank_title="";
            $scope.newBank.rate="";
            $scope.newBank.APR="";
            $scope.newBank.bank_url="";             
            return '';
        }


    }) ;